import React,{useState} from 'react'

function Task() {

    let selectedMobile = (product,type) => {
        alert(`You have selected ${product} ${type}`);
    }

        const [expanded, setExpanded] = useState({});
        const categories = [
          {
            title: "Mobiles",
            type: "mobile",
            imageSrc: "./images/images.png",
            text: "Samsung",
            item:"./images/samsung.avif",
            text1:"Apple",
            item1:"./images/Apple-pic.webp"
          },
          {
            title: "Loptops",
            type: "laptop",
            imageSrc: "./images/loptop-pic.jpeg",
            text: "Apple",
            item:"./images/laptop-apple.webp",
            text1:"Dell",
            item1:"./images/dell-laptop.jpeg"
          },
          {
            title: "Watches",
            type: "watch",
            imageSrc: "./images/watch2.jpeg",
            text: "RoleX",
            item:"./images/Rolex.jpeg",
            text1:"Titan",
            item1:"./images/titan.webp"
          },
        ];
      
        const toggleCategory = (index) => {
          setExpanded((prevState) => ({ ...prevState, [index]: !prevState[index] }));
        };

        
      
  return (
    <div>
          <ul className="Task">
      {categories.map((category, index) => (
        <li key={index}>
          <div className="Task-banner" onClick={() => toggleCategory(index)}>
            <img src={category.imageSrc} alt={category.title} />
            <h2>{category.title}</h2>
          </div>
          {expanded[index] && (
            <ul className="Task2">
              <li onClick={() => {
                selectedMobile(category.text,category.type)
              }}>{category.text}</li>
              <li onClick={() => {
                selectedMobile(category.text,category.type)
              }} ><img src={category.item} className='src'></img></li>
              <li onClick={() => {
                selectedMobile(category.text1,category.type)
              }}>{category.text1}</li> 
              <li onClick={() => {
                selectedMobile(category.text1,category.type)
              }}><img src={category.item1} className='src'></img></li>          
              </ul>
          )}
        </li>
      ))}
    </ul>

    </div>
  )
}

export default Task