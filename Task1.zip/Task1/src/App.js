import logo from './logo.svg';
import './App.css';
import Task from './Components/Task';

function App() {
  return (
    <div className="App">
    <Task></Task>
    </div>
  );
}

export default App;
