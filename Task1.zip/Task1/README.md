# Task1
According to the requirement stated ,I have completed building components using html, react & javascript. 
Used techniques to ensure the components with disabilities with the help of browers & devices.
This task is accessable by clicking on it , for animation i have used CSS(cascading style sheet).
Therefore, my task for the requirement is accessable when performed an action on click & the components are also user friendly to access.
